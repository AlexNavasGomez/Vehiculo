
package vehiculo;

/**
 *
 * @author 
 */
public class Main {
    
      public static void main(String[] args) {
        VehiculoANG2223 miVehiculoANG2223;
        int stockActual;
        
        miVehiculoANG2223 = new VehiculoANG2223("Seat",18000,100);
        operativaVehiculosANG2223(miVehiculoANG2223, 50); 
        stockActual = miVehiculoANG2223.obtenerStock();
        System.out.println("El stock actual es "+ stockActual );
    }

    private static Integer operativaVehiculosANG2223(VehiculoANG2223 miVehiculoANG2223, Entero cantidad) {
        try
        {
            System.out.println("Venta de Vehiculos");
            miVehiculoANG2223.vender(20);
        } catch (Exception e)
        {
            System.out.print("Fallo al vender");
        }
        
        try
        {
            System.out.println("Compra de Vehiculos");
            miVehiculoANG2223.comprar(100);
        } catch (Exception e)
        {
            System.out.print("Fallo al comprar");
        }
    }

}
    
